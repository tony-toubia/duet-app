export { DuetAudio } from './DuetAudio';
export type {
  AudioSetupResult,
  AudioDataEvent,
  VoiceActivityEvent,
  ConnectionStateEvent,
  PlayAudioResult,
} from './DuetAudio';
